@echo off
title Eye Controlled Mouse - Setup
color 0A
echo ====================================================
echo     Eye Controlled Mouse - Environment Setup
echo ====================================================
echo.

REM ---- Upgrade pip first ----
echo [1/5] Upgrading pip...
python -m pip install --upgrade pip

REM ---- Create virtual environment (optional but clean) ----
if not exist venv (
    echo [2/5] Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate

REM ---- Install compatible versions ----
echo [3/5] Installing dependencies...
pip install --upgrade mediapipe==0.10.14 protobuf==4.25.3
pip install --upgrade opencv-python pyautogui pyttsx3 SpeechRecognition numpy
pip install --upgrade pyaudio

REM ---- Verify installation ----
echo [4/5] Verifying key libraries...
pip show mediapipe protobuf | findstr "Version"

REM ---- Optional cleanup ----
echo [5/5] Cleaning old calibration (optional)...
if exist calibration.json (
    del calibration.json
    echo Old calibration removed. A new calibration will start on next run.
)

echo.
echo ====================================================
echo ✅ Setup complete!
echo Run your project with:
echo   venv\Scripts\activate
echo   python eye_controlled_mouse.py
echo ====================================================
pause
