import tkinter as tk
import threading
import speech_recognition as sr
import requests
import time
import os
import webbrowser
import shutil
import subprocess
import fnmatch
import traceback
import pyaudio

LOG_STDOUT = "assistant_stdout.log"
LOG_STDERR = "assistant_stderr.log"

def log_stdout(msg):
    try:
        with open(LOG_STDOUT, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass

def log_stderr(msg):
    try:
        with open(LOG_STDERR, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except Exception:
        pass

class VoiceAssistantGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Voice Assistant")
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        win_w, win_h = 140, 120
        x = screen_w - win_w - 20
        y = screen_h - win_h - 60
        self.root.geometry(f"{win_w}x{win_h}+{x}+{y}")
        self.root.overrideredirect(False)
        self.root.attributes("-topmost", True)

        self.emoji_btn = tk.Button(self.root, text="🎙️", font=("Segoe UI Emoji", 48), command=self.listen_voice)
        self.emoji_btn.pack(expand=True, fill=tk.BOTH)

        self.text_var = tk.StringVar()
        self.text_var.set("Idle")
        self.text_label = tk.Label(self.root, textvariable=self.text_var, font=("Arial", 11), bg="white")
        self.text_label.pack(fill=tk.X)

        # Recognizer configuration
        self.recognizer = sr.Recognizer()
        # Reduce false positives & tune thresholds
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.energy_threshold = 300
        self.recognizer.pause_threshold = 0.6
        self.recognizer.operation_timeout = None

        # Microphone and background thread
        self.mic = None
        self._bg_thread = None
        self._stop_bg = threading.Event()
        self._manual_trigger = threading.Event()

        # Try to initialize microphone and start background listener thread
        try:
            self.mic = sr.Microphone()
            # calibrate ambient noise once
            with self.mic as source:
                self._set_status("Calibrating...")
                try:
                    self.recognizer.adjust_for_ambient_noise(source, duration=1.0)
                except Exception:
                    pass
            # start background listener thread (holds mic context)
            self._bg_thread = threading.Thread(target=self._background_listen_loop, daemon=True)
            self._bg_thread.start()
            log_stdout("Background listener thread started.")
        except Exception as e:
            self._set_status("No microphone")
            log_stderr(f"Microphone init failed: {repr(e)}")
            self.mic = None

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.mainloop()

    def _set_status(self, text):
        try:
            self.root.after(0, lambda: self.text_var.set(text))
        except Exception:
            try:
                self.text_var.set(text)
            except Exception:
                pass

    def listen_voice(self):
        # don't open Microphone here — just signal the background thread to capture once
        if not self.mic:
            self._set_status("No mic")
            return
        self._manual_trigger.set()

    def _manual_listen_capture(self):
        # kept as a no-op to avoid accidental mic re-open; use manual_trigger instead
        self._set_status("Use the mic button to trigger capture; background listener will handle it.")
        return

    def _background_listen_loop(self):
        """
        Single loop that keeps the Microphone open. It listens in short chunks,
        checks for wake phrase, then performs an active capture for the real command.
        This avoids context-manager conflicts and repeated start/stop.
        """
        if not self.mic:
            return
        try:
            with self.mic as source:
                # continuous listening loop
                while not self._stop_bg.is_set():
                    try:
                        # short chunk to detect wake phrase (non-blocking-ish)
                        audio = self.recognizer.listen(source, timeout=3, phrase_time_limit=3)
                        try:
                            text = self.recognizer.recognize_google(audio).lower()
                        except Exception:
                            # ignore intermittent chunk recognition failures
                            continue
                        log_stdout(f"[wake chunk] {text}")
                        if "hey assistant" in text or "hey assistant," in text or text.strip() == "assistant":
                            # wake detected, do active capture
                            self._set_status("Wake detected")
                            # small pause to let user speak full command
                            time.sleep(0.35)
                            try:
                                # active capture: listen for command phrase
                                self._set_status("Listening for command...")
                                audio_cmd = self.recognizer.listen(source, timeout=6, phrase_time_limit=8)
                                try:
                                    cmd_text = self.recognizer.recognize_google(audio_cmd)
                                except Exception as e:
                                    self._set_status("Could not understand")
                                    log_stderr(f"[capture recognize] {repr(e)}")
                                    continue
                                self._set_status(cmd_text)
                                log_stdout(f"[command] {cmd_text}")
                                self._process_command_text(cmd_text)
                                # after handling command, short pause
                                time.sleep(0.3)
                                self._set_status("Idle")
                            except sr.WaitTimeoutError:
                                self._set_status("No command heard")
                                log_stderr("[capture timeout]")
                            except Exception as e:
                                self._set_status("Error capturing")
                                log_stderr(f"[capture error] {repr(e)}")
                        # short sleep to avoid busy-loop
                        time.sleep(0.05)
                    except sr.WaitTimeoutError:
                        # no speech in this interval, continue
                        continue
                    except Exception as e:
                        log_stderr(f"[bg loop error] {repr(e)}")
                        # avoid tight crash loop
                        time.sleep(0.8)
        except Exception as e:
            
            log_stderr(f"[background_listen_wrapper] {repr(e)}")

    def _process_command_text(self, text):
        # try API then local fallback and update status
        try:
            result = self._call_api(text)
            if not result or "Could not open" in result or result.lower().startswith("api error"):
                fallback = self._open_local(text)
                self._set_status(fallback)
            else:
                self._set_status(result)
        except Exception as e:
            log_stderr(f"[process_command_text] {repr(e)}")
            self._set_status("Command failed")

    def _call_api(self, text):
        api_url = "http://127.0.0.1:5000/open"
        try:
            resp = requests.post(api_url, json={"item": text}, timeout=6)
            log_stdout(f"[api] {text} -> {resp.status_code} {resp.text}")
            try:
                return resp.json().get("result", resp.text)
            except Exception:
                return resp.text
        except Exception as e:
            log_stderr(f"[api call failed] {repr(e)}")
            return f"API error: {e}"

    def _open_local(self, item):
        """Robust local opener: explicit mappings, exe lookup, Start Menu .lnk, PATH, url and file search."""
        target = (item or "").strip().lower()
        if target.startswith("open "):
            target = target.replace("open ", "", 1).strip()
        if target.startswith("file "):
            target = target.replace("file ", "", 1).strip()

        # quick URL handling
        if target.startswith("http") or target.startswith("www") or ("." in target and " " not in target):
            url = target if target.startswith("http") else f"https://{target}"
            try:
                webbrowser.open(url)
                return f"Opening website: {url}"
            except Exception as e:
                log_stderr(f"[open url] {repr(e)}")
                return f"Failed to open website: {e}"

        # helper: try launching executable paths or names
        def try_launch_exes(names):
            for n in names:
                if not n:
                    continue
                # absolute path or found in PATH
                if os.path.isabs(n) and os.path.exists(n):
                    try:
                        subprocess.Popen([n])
                        return True, f"Opened: {n}"
                    except Exception as e:
                        return False, f"Failed to open {n}: {e}"
                exe = shutil.which(n) or shutil.which(n + ".exe")
                if exe:
                    try:
                        subprocess.Popen([exe])
                        return True, f"Opened: {exe}"
                    except Exception as e:
                        return False, f"Failed to open {exe}: {e}"
            return False, None

        # explicit app mappings (common names -> exe candidates or url fallback)
        APP_EXEC_MAP = {
            "chrome": ["chrome", "chrome.exe", "msedge", "msedge.exe"],
            "edge": ["msedge", "msedge.exe", "microsoftedge"],
            "firefox": ["firefox", "firefox.exe"],
            "spotify": ["spotify", "spotify.exe"],
            "vscode": ["code", "code.exe", "vscode"],
            "visual studio code": ["code", "code.exe"],
            "powerpoint": ["powerpnt", "powerpnt.exe"],
            "word": ["winword", "winword.exe"],
            "excel": ["excel", "excel.exe"],
            "notepad": ["notepad", "notepad.exe"],
            "calculator": ["calc", "calc.exe"],
            "whatsapp": ["WhatsApp", "WhatsApp.exe", "WhatsAppDesktop.exe"],
            "teams": ["Teams", "Teams.exe", "teams.exe"],
            "discord": ["discord", "discord.exe"],
            "steam": ["steam", "steam.exe"],
            "slack": ["slack", "slack.exe"],
            "command prompt": ["cmd", "cmd.exe"],
            "powershell": ["powershell", "pwsh", "powershell.exe"],
            "explorer": ["explorer", "explorer.exe"],
            "camera": ["microsoft.windows.camera_8wekyb3d8bbwe:App"],  # UWP placeholder
        }

        # first check explicit mapping keys
        for key, exe_candidates in APP_EXEC_MAP.items():
            if key in target:
                # try exe candidates
                ok, msg = try_launch_exes(exe_candidates)
                if ok:
                    return msg
                # fallback to URLs for some apps
                if "youtube" in key:
                    webbrowser.open("https://www.youtube.com")
                    return "Opening YouTube"
                if "whatsapp" in key:
                    try:
                        webbrowser.open("https://web.whatsapp.com")
                        return "Opening WhatsApp Web"
                    except Exception:
                        pass
                # fall through to Start Menu search

        # special-case common website names
        if "youtube" in target:
            try:
                webbrowser.open("https://www.youtube.com")
                return "Opening YouTube"
            except Exception as e:
                log_stderr(f"[youtube open] {repr(e)}")

        if "google" in target and "drive" not in target and "docs" not in target:
            try:
                webbrowser.open("https://www.google.com")
                return "Opening Google"
            except Exception as e:
                log_stderr(f"[google open] {repr(e)}")

        # Try Start Menu (.lnk) matches - strongly preferred for installed apps
        start_dirs = [
            os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs"),
            os.path.join(os.environ.get("ProgramData", ""), r"Microsoft\Windows\Start Menu\Programs"),
        ]
        for sd in start_dirs:
            if not sd or not os.path.exists(sd):
                continue
            for root, dirs, files in os.walk(sd):
                for f in files:
                    lf = f.lower()
                    if lf.endswith(".lnk") and target in lf:
                        try:
                            full = os.path.join(root, f)
                            os.startfile(full)
                            return f"Opening shortcut: {f}"
                        except Exception as e:
                            log_stderr(f"[startmenu open] {repr(e)}")

        # Try PATH / exe names directly (user might speak exact exe)
        exe_ok, exe_msg = try_launch_exes([target, target.replace(" ", "")])
        if exe_ok:
            return exe_msg

        # Search common folders for non-image preferred files (.lnk/.exe/.url first)
        IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".ico"}
        PREFERRED_EXTS = {".exe", ".lnk", ".url", ".html", ".htm", ".pdf", ".docx", ".pptx"}
        search_dirs = [
            os.path.join(os.path.expanduser("~"), "Desktop"),
            os.path.join(os.path.expanduser("~"), "Downloads"),
            os.path.join(os.path.expanduser("~"), "Documents"),
        ]
        found_preferred = None
        found_image = None
        for base in search_dirs:
            if not base or not os.path.exists(base):
                continue
            for root, dirs, files in os.walk(base):
                for name in files:
                    lname = name.lower()
                    if target in lname:
                        ext = os.path.splitext(lname)[1]
                        full = os.path.join(root, name)
                        if ext in PREFERRED_EXTS:
                            found_preferred = full
                            break
                        if ext in IMAGE_EXTS and found_image is None:
                            found_image = full
                if found_preferred:
                    break
            if found_preferred:
                break

        if found_preferred:
            try:
                os.startfile(found_preferred)
                return f"Opening file: {found_preferred}"
            except Exception as e:
                log_stderr(f"[open found preferred] {repr(e)}")
                return f"Found file but failed to open: {e}"

        # if we only found image, avoid opening it unless nothing else
        if found_image:
            try:
                os.startfile(found_image)
                return f"Opening image file: {found_image}"
            except Exception as e:
                log_stderr(f"[open image fallback] {repr(e)}")

        # Last resort: try Windows start/search which often finds Store/UWP app or shows results
        try:
            subprocess.Popen(f'start "" "{item}"', shell=True)
            return f"Trying Windows Start for: {item}"
        except Exception as e:
            log_stderr(f"[start fallback] {repr(e)}")

        return f"Could not open: {item}"

    def _on_close(self):
        # stop background thread and exit
        try:
            self._stop_bg.set()
        except Exception:
            pass
        # give thread a moment to exit
        time.sleep(0.2)
        try:
            self.root.destroy()
        except Exception:
            pass

    def manual_trigger(self):
        # previously opened a Microphone inside UI thread -> caused AssertionError
        # now just signal background thread (which already holds the Microphone)
        self._manual_trigger.set()

if __name__ == "__main__":
    try:
        VoiceAssistantGUI()
    except Exception as e:
        log_stderr(f"[main crash] {repr(e)}")
        raise