import cv2
import mediapipe as mp
import pyautogui
import numpy as np
import time
import winsound
import keyboard
import threading
import pyttsx3
import json

# ----------------- CONFIG -----------------
EAR_THRESH = 0.25
BLINK_MIN = 0.05
SMOOTHING = 0.97
MOVE_GAIN = 0.07
RANGE_EXPAND = 0.10
DEADZONE = 0.008
SCROLL_DURATION = 10.0
CALIB_FRAMES = 60
pyautogui.FAILSAFE = False

# ----------------- INIT -----------------
mp_face_mesh = mp.solutions.face_mesh
engine = pyttsx3.init()
engine.setProperty("rate", 165)

# --------------- UTILITIES ---------------
def speak_async(text):
    threading.Thread(target=lambda: engine.say(text) or engine.runAndWait(), daemon=True).start()

def speak_blocking(text):
    engine.say(text)
    engine.runAndWait()

def beep(freq, dur):
    winsound.Beep(freq, dur)

# --------------- EYE ASPECT RATIO ---------------
def ear(landmarks, eye_indices):
    p = np.array([(landmarks[i].x, landmarks[i].y) for i in eye_indices])
    v1 = np.linalg.norm(p[1] - p[5])
    v2 = np.linalg.norm(p[2] - p[4])
    h = np.linalg.norm(p[0] - p[3])
    return (v1 + v2) / (2.0 * h)

# --------------- AUTO CALIBRATION ---------------
def auto_calibrate(cap, face_mesh):
    print("🧭 Auto-calibrating... please move head slowly in all directions")
    x_vals, y_vals = [], []
    for _ in range(CALIB_FRAMES):
        ret, frame = cap.read()
        if not ret:
            continue
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = face_mesh.process(rgb)
        if res.multi_face_landmarks:
            face = res.multi_face_landmarks[0]
            x = face.landmark[1].x
            y = face.landmark[1].y
            x_vals.append(x)
            y_vals.append(y)
        cv2.imshow("Calibrating...", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    cv2.destroyWindow("Calibrating...")
    return {
        "xmin": min(x_vals), "xmax": max(x_vals),
        "ymin": min(y_vals), "ymax": max(y_vals)
    }

# --------------- MAIN -----------------
def main():
    cap = cv2.VideoCapture(0)
    screen_w, screen_h = pyautogui.size()

    with mp_face_mesh.FaceMesh(refine_landmarks=True) as face_mesh:
        calib = auto_calibrate(cap, face_mesh)
        print("✅ Calibration complete.")
        speak_async("Calibration complete. System ready.")

        xmin, xmax = calib["xmin"], calib["xmax"]
        ymin, ymax = calib["ymin"], calib["ymax"]

        prev_x, prev_y = 0.5, 0.5
        smoothed_x, smoothed_y = prev_x, prev_y
        both_blink_timestamps = []
        left_closed = right_closed = both_closed = False
        scroll_mode = False
        scroll_end_time = 0

        print("🖱️ Controls: A=Left, D=Right, W=Double | 3 blinks=Scroll | 5 blinks=Exit/Continue")

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            res = face_mesh.process(rgb)
            now = time.time()

            # Keyboard fallback clicks
            if keyboard.is_pressed("a"):
                pyautogui.click()
                beep(700, 40)
                time.sleep(0.25)
            elif keyboard.is_pressed("d"):
                pyautogui.rightClick()
                beep(600, 40)
                time.sleep(0.25)
            elif keyboard.is_pressed("w"):
                pyautogui.doubleClick()
                beep(800, 50)
                time.sleep(0.3)

            if res.multi_face_landmarks:
                face = res.multi_face_landmarks[0]
                # Landmarks for eyes
                LEFT = [33, 160, 158, 133, 153, 144]
                RIGHT = [362, 385, 387, 263, 373, 380]

                left_ear = ear(face.landmark, LEFT)
                right_ear = ear(face.landmark, RIGHT)

                # ---------- Eye Blink Detection ----------
                if left_ear < EAR_THRESH and not left_closed:
                    left_closed = True
                elif left_ear >= EAR_THRESH and left_closed:
                    left_closed = False
                    pyautogui.click()
                    beep(700, 40)

                if right_ear < EAR_THRESH and not right_closed:
                    right_closed = True
                elif right_ear >= EAR_THRESH and right_closed:
                    right_closed = False
                    pyautogui.rightClick()
                    beep(600, 40)

                # ---------- Both Eyes Blink Sequence ----------
                if left_ear < EAR_THRESH and right_ear < EAR_THRESH:
                    if not both_closed:
                        both_closed = True
                        both_close_start = now
                else:
                    if both_closed:
                        both_closed = False
                        dur = now - both_close_start
                        if dur >= BLINK_MIN:
                            if both_blink_timestamps and (now - both_blink_timestamps[-1]) > 3.0:
                                both_blink_timestamps = []
                            both_blink_timestamps.append(now)
                            count = len(both_blink_timestamps)
                            beep(950 + count * 50, 50)
                            color = (0, 255, 0) if count < 3 else (0, 255, 255) if count == 3 else (0, 0, 255)
                            cv2.putText(frame, f"Blinks: {count}", (10, 35),
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

                            if count == 3:
                                scroll_mode = True
                                scroll_end_time = now + SCROLL_DURATION
                                speak_async("Scroll mode activated for ten seconds.")
                                both_blink_timestamps = []

                            elif count >= 5:
                                both_blink_timestamps = []
                                speak_blocking("You blinked five times. Press E to exit or C to continue.")
                                decision = None
                                wait_start = time.time()
                                while time.time() - wait_start < 10.0:
                                    k = cv2.waitKey(1) & 0xFF
                                    if k == ord("e"):
                                        decision = "exit"
                                        break
                                    elif k == ord("c"):
                                        decision = "continue"
                                        break

                                if decision == "exit":
                                    speak_blocking("Exiting now. Goodbye.")
                                    cap.release()
                                    cv2.destroyAllWindows()
                                    return
                                else:
                                    speak_async("Continuing.")

                # ---------- Cursor Movement ----------
                nx = face.landmark[1].x
                ny = face.landmark[1].y

                nx = np.clip((nx - xmin) / (xmax - xmin), 0, 1)
                ny = np.clip((ny - ymin) / (ymax - ymin), 0, 1)

                smoothed_x = SMOOTHING * smoothed_x + (1 - SMOOTHING) * nx
                smoothed_y = SMOOTHING * smoothed_y + (1 - SMOOTHING) * ny

                dx = smoothed_x - prev_x
                dy = smoothed_y - prev_y
                if abs(dx) < DEADZONE:
                    dx = 0
                if abs(dy) < DEADZONE:
                    dy = 0

                prev_x, prev_y = smoothed_x, smoothed_y
                mx = screen_w * smoothed_x
                my = screen_h * smoothed_y

                if not scroll_mode:
                    pyautogui.moveTo(mx, my)

                # ---------- Scroll Mode ----------
                if scroll_mode:
                    head_move = dy
                    if head_move > 0.005:
                        pyautogui.scroll(-30)
                    elif head_move < -0.005:
                        pyautogui.scroll(30)
                    if now > scroll_end_time:
                        scroll_mode = False
                        speak_async("Scroll mode ended.")

                cv2.putText(frame, f"Scroll: {'ON' if scroll_mode else 'OFF'}", (10, 70),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255) if scroll_mode else (255, 255, 255), 2)

            cv2.imshow("Eye Controlled Mouse", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
