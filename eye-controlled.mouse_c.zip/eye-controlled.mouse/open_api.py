from flask import Flask, request, jsonify
import os
import subprocess
import shutil
import webbrowser
import re

app = Flask(__name__)

def normalize(text: str) -> str:
    if not text:
        return ""
    t = text.lower().strip()
    # strip common prefixes
    for p in ("open ", "please ", "please open ", "launch ", "start "):
        if t.startswith(p):
            t = t[len(p):].strip()
    # normalize common spoken variants
    t = t.replace("power point", "powerpoint")
    t = t.replace("power point ", "powerpoint ")
    t = t.replace("visual studio code", "vscode")
    t = t.replace("vs code", "vscode")
    t = t.replace("whats app", "whatsapp")
    t = re.sub(r"\s+", " ", t)
    # map mis-heard variants to canonical tokens
    t = t.replace("co pilot", "copilot").replace("ko pilot", "copilot").replace("copil", "copilot").replace("ko pilot", "copilot")
    return t

# Replace APP_MAP with aliases and URL/exe candidates
APP_MAP = {
    "chrome": {"aliases": ["chrome", "google chrome"], "exe": ["chrome", "chrome.exe"], "url": None},
    "edge": {"aliases": ["edge", "microsoft edge"], "exe": ["msedge", "msedge.exe"], "url": None},
    "firefox": {"aliases": ["firefox"], "exe": ["firefox", "firefox.exe"], "url": None},
    "spotify": {"aliases": ["spotify"], "exe": ["spotify", "spotify.exe"], "url": "https://open.spotify.com"},
    "youtube": {"aliases": ["youtube", "you tube"], "exe": None, "url": "https://www.youtube.com"},
    "google": {"aliases": ["google"], "exe": None, "url": "https://www.google.com"},
    "gmail": {"aliases": ["gmail", "mail"], "exe": None, "url": "https://mail.google.com"},
    "powerpoint": {"aliases": ["powerpoint", "ppt", "power point"], "exe": ["powerpnt", "powerpnt.exe"], "url": None},
    "word": {"aliases": ["word", "ms word"], "exe": ["winword", "winword.exe"], "url": None},
    "excel": {"aliases": ["excel"], "exe": ["excel", "excel.exe"], "url": None},
    "whatsapp": {"aliases": ["whatsapp", "what's app"], "exe": ["WhatsApp", "WhatsApp.exe", "WhatsAppDesktop.exe"], "url": "https://web.whatsapp.com"},
    "vscode": {"aliases": ["vscode", "visual studio code", "vs code"], "exe": ["code", "code.exe"], "url": None},
    "notepad": {"aliases": ["notepad"], "exe": ["notepad", "notepad.exe"], "url": None},
    "calculator": {"aliases": ["calculator", "calc"], "exe": ["calc", "calc.exe"], "url": None},
    "copilot": {"aliases": ["copilot", "co pilot"], "exe": ["Copilot", "Copilot.exe"], "url": "https://copilot.microsoft.com"},
    "microsoft store": {"aliases": ["microsoft store", "store"], "exe": None, "url": None},
    "paint": {"aliases": ["paint", "mspaint"], "exe": ["mspaint", "mspaint.exe"], "url": None},
    "instagram": {"aliases": ["instagram", "insta"], "exe": None, "url": "https://www.instagram.com"},
    "facebook": {"aliases": ["facebook", "fb"], "exe": None, "url": "https://www.facebook.com"},
    "twitter": {"aliases": ["twitter", "x"], "exe": None, "url": "https://twitter.com"},
    "telegram": {"aliases": ["telegram"], "exe": ["Telegram", "Telegram.exe", "TelegramDesktop.exe"], "url": "https://web.telegram.org"},
    "linkedin": {"aliases": ["linkedin"], "exe": None, "url": "https://www.linkedin.com"},
    "chatgpt": {"aliases": ["chatgpt", "chat gpt", "chat g p t"], "exe": None, "url": "https://chat.openai.com"},
    "camera": {"aliases": ["camera"], "exe": None, "url": None},
    "files": {"aliases": ["files", "file explorer", "explorer", "file manager"], "exe": ["explorer", "explorer.exe"], "url": None},
    "documents": {"aliases": ["documents", "my documents", "document"], "exe": None, "url": None},
    "downloads": {"aliases": ["downloads", "my downloads", "download"], "exe": None, "url": None},
    # shopping / streaming / food / maps
    "flipkart": {"aliases": ["flipkart"], "exe": None, "url": "https://www.flipkart.com"},
    "meesho": {"aliases": ["meesho"], "exe": None, "url": "https://www.meesho.com"},
    "amazon": {"aliases": ["amazon"], "exe": None, "url": "https://www.amazon.in"},
    "myntra": {"aliases": ["myntra"], "exe": None, "url": "https://www.myntra.com"},
    "shop": {"aliases": ["shopsy", "shopsee", "shopsy", "shopsy"], "exe": None, "url": "https://www.shop.com"},
    "hotstar": {"aliases": ["hotstar", "jio hotstar"], "exe": None, "url": "https://www.hotstar.com"},
    "zomato": {"aliases": ["zomato"], "exe": None, "url": "https://www.zomato.com"},
    "swiggy": {"aliases": ["swiggy"], "exe": None, "url": "https://www.swiggy.com"},
    "netflix": {"aliases": ["netflix"], "exe": None, "url": "https://www.netflix.com"},
    "primevideo": {"aliases": ["amazon prime", "prime video", "primevideo"], "exe": None, "url": "https://www.primevideo.com"},
    "jiomart": {"aliases": ["jiomart"], "exe": None, "url": "https://www.jiomart.com"},
    "jiotv": {"aliases": ["jiotv"], "exe": None, "url": "https://www.jiotv.com"},
    "maps": {"aliases": ["maps", "google maps"], "exe": None, "url": "https://www.google.com/maps"},
}

def try_launch_exes(names):
    if not names:
        return False, None
    for n in names:
        if not n:
            continue
        # absolute path
        if os.path.isabs(n) and os.path.exists(n):
            try:
                subprocess.Popen([n])
                return True, f"Launched {n}"
            except Exception as e:
                return False, f"Failed: {e}"
        exe = shutil.which(n) or shutil.which(n + ".exe")
        if exe:
            try:
                subprocess.Popen([exe])
                return True, f"Launched {exe}"
            except Exception as e:
                return False, f"Failed: {e}"
    return False, None

def open_startmenu_shortcut(name):
    start_dirs = [
        os.path.join(os.environ.get("APPDATA", ""),"Microsoft\\Windows\\Start Menu\\Programs"),
        os.path.join(os.environ.get("ProgramData", ""),"Microsoft\\Windows\\Start Menu\\Programs"),
    ]
    target = name.lower()
    for sd in start_dirs:
        if not sd or not os.path.exists(sd):
            continue
        # only a shallow search (not whole home) to keep it fast
        for root, dirs, files in os.walk(sd):
            for f in files:
                if f.lower().endswith(".lnk") and target in f.lower():
                    try:
                        path = os.path.join(root, f)
                        os.startfile(path)
                        return True, f"Opened shortcut {f}"
                    except Exception as e:
                        return False, f"Shortcut found but failed: {e}"
    return False, None

def find_files_limited(name, max_results=20):
    """Search common folders for files matching name. Return up to max_results paths.
    Prefer shortcuts/executables and common document types."""
    name = (name or "").lower()
    if not name:
        return []
    search_dirs = [
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "Documents"),
        os.path.join(os.path.expanduser("~"), "Downloads"),
        os.path.join(os.environ.get("APPDATA", ""),"Microsoft\\Windows\\Start Menu\\Programs"),
        os.path.join(os.environ.get("ProgramData", ""),"Microsoft\\Windows\\Start Menu\\Programs"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files")),
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
    ]
    PREFERRED_EXTS = [".lnk", ".exe", ".url", ".pdf", ".docx", ".doc", ".pptx", ".xlsx", ".txt", ".html", ".htm"]
    results = []
    seen = set()
    for base in search_dirs:
        if not base or not os.path.exists(base):
            continue
        for root, dirs, files in os.walk(base):
            for f in files:
                lf = f.lower()
                if name in lf:
                    full = os.path.join(root, f)
                    if full in seen:
                        continue
                    seen.add(full)
                    results.append((full, os.path.splitext(lf)[1]))
                    if len(results) >= max_results:
                        break
            if len(results) >= max_results:
                break
        if len(results) >= max_results:
            break
    # sort results: preferred extensions first
    results.sort(key=lambda t: (0 if t[1] in PREFERRED_EXTS else 1, t[0]))
    return [r[0] for r in results]

def open_file_path(path):
    """Open a file or shortcut using the system default. Return message and success flag."""
    try:
        if not os.path.exists(path):
            return False, f"File not found: {path}"
        os.startfile(path)
        return True, f"Opened file: {path}"
    except Exception as e:
        return False, f"Failed to open {path}: {e}"

def _match_key(item: str, key_info: dict) -> bool:
    """Return True if any alias matches as whole word in item."""
    for alias in key_info.get("aliases", []):
        # build regex to match alias as whole word sequence (handles multi-word aliases)
        pattern = r"\b" + re.escape(alias) + r"\b"
        if re.search(pattern, item):
            return True
    return False

def open_anything(item: str) -> str:
    item = normalize(item)
    if not item:
        return "No item provided."

    # Prevent overly-broad single word 'open' from file-scanning
    if item.strip() == "" or item.strip().lower() == "open":
        return "Please specify what to open."

    # direct folder shortcuts
    if re.search(r"\b(files|file explorer|explorer|file manager)\b", item):
        try:
            path = os.path.expanduser("~")
            os.startfile(path)
            return f"Opening Files: {path}"
        except Exception as e:
            return f"Failed to open Files: {e}"
    if re.search(r"\b(documents|my documents|document)\b", item):
        try:
            path = os.path.join(os.path.expanduser("~"), "Documents")
            os.startfile(path)
            return f"Opening Documents: {path}"
        except Exception as e:
            return f"Failed to open Documents: {e}"
    if re.search(r"\b(downloads|my downloads|download)\b", item):
        try:
            path = os.path.join(os.path.expanduser("~"), "Downloads")
            os.startfile(path)
            return f"Opening Downloads: {path}"
        except Exception as e:
            return f"Failed to open Downloads: {e}"

    # special URIs
    if re.search(r"\bmicrosoft store\b", item) or item == "store":
        try:
            subprocess.Popen('start "" "ms-windows-store://home"', shell=True)
            return "Opening Microsoft Store"
        except Exception as e:
            return f"Failed to open Microsoft Store: {e}"
    if re.search(r"\bcamera\b", item):
        try:
            subprocess.Popen('start "" "microsoft.windows.camera:"', shell=True)
            return "Opening Camera"
        except Exception as e:
            return f"Failed to open Camera: {e}"

    # URL/domain quick path
    if item.startswith("http") or item.startswith("www") or ("." in item and " " not in item):
        url = item if item.startswith("http") else f"https://{item}"
        try:
            webbrowser.open(url)
            return f"Opening website: {url}"
        except Exception as e:
            return f"Failed to open website: {e}"

    # explicit mapping: prefer exe/startmenu then URL
    for key, info in APP_MAP.items():
        if _match_key(item, info):
            # try exe candidates
            ok, msg = try_launch_exes(info.get("exe"))
            if ok:
                return msg
            # try start menu .lnk
            ok, msg = open_startmenu_shortcut(key)
            if ok:
                return msg
            # try URL fallback
            url = info.get("url")
            if url:
                try:
                    webbrowser.open(url)
                    return f"Opening {key} (web): {url}"
                except Exception as e:
                    return f"Failed to open {key} web: {e}"
            # last resort Windows Start
            try:
                subprocess.Popen(f'start "" "{key}"', shell=True)
                return f"Trying Windows Start for: {key}"
            except Exception as e:
                return f"Could not open {key}: {e}"

    # try PATH / exe directly
    ok, msg = try_launch_exes([item, item.replace(" ", "")])
    if ok:
        return msg

    # file search fallback (limited)
    matches = find_files_limited(item, max_results=8)
    if matches:
        ok, msg = open_file_path(matches[0])
        return msg if ok else f"Found file but failed to open: {matches[0]}"

    try:
        subprocess.Popen(f'start "" "{item}"', shell=True)
        return f"Trying Windows Start for: {item}"
    except Exception as e:
        return f"Could not open: {item} - {e}"

@app.route('/open', methods=['POST'])
def open_api():
    data = request.get_json() or {}
    item = data.get('item') or data.get('command') or ''
    try:
        result = open_anything(item)
    except Exception as e:
        result = f"open_anything failed: {e}"
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=5000, debug=False)

